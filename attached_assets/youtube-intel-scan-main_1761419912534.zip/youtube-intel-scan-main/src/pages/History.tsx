import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, Download, Eye, Calendar } from "lucide-react";

const mockAnalyses = [
  {
    id: "1",
    channelName: "Lenny's Podcast",
    videoTitle: "Building Products That Scale - Interview with Shreyas Doshi",
    analyzedAt: "2024-01-15T10:30:00Z",
    insightsCount: 12,
    status: "completed",
  },
  {
    id: "2",
    channelName: "ProductSchool",
    videoTitle: "Product-Market Fit: Framework & Best Practices",
    analyzedAt: "2024-01-14T15:45:00Z",
    insightsCount: 8,
    status: "completed",
  },
  {
    id: "3",
    channelName: "Product Hunt",
    videoTitle: "From 0 to 1: Launching Your First Product",
    analyzedAt: "2024-01-13T09:20:00Z",
    insightsCount: 15,
    status: "completed",
  },
  {
    id: "4",
    channelName: "Lenny's Podcast",
    videoTitle: "User Research Methods for Product Managers",
    analyzedAt: "2024-01-12T14:10:00Z",
    insightsCount: 10,
    status: "completed",
  },
];

export default function History() {
  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Analysis History</h1>
          <p className="text-muted-foreground mt-2">
            Browse your past transcript analyses and insights
          </p>
        </div>
        <Button variant="outline">
          <Download className="mr-2 h-4 w-4" />
          Export All
        </Button>
      </div>

      <div className="space-y-4">
        {mockAnalyses.map((analysis, index) => (
          <Card
            key={analysis.id}
            className="border-border/50 hover:border-primary/50 transition-all animate-fade-in"
            style={{ animationDelay: `${index * 75}ms` }}
          >
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-2 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant="secondary" className="text-xs">
                      {analysis.channelName}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      <FileText className="mr-1 h-3 w-3" />
                      {analysis.insightsCount} insights
                    </Badge>
                  </div>
                  <CardTitle className="text-lg line-clamp-2">
                    {analysis.videoTitle}
                  </CardTitle>
                  <CardDescription className="flex items-center gap-2">
                    <Calendar className="h-3 w-3" />
                    {new Date(analysis.analyzedAt).toLocaleDateString("en-US", {
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline">
                    <Eye className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant="outline">
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
          </Card>
        ))}
      </div>

      {/* Empty State */}
      {mockAnalyses.length === 0 && (
        <Card className="border-dashed border-2 border-border/50">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <div className="p-4 rounded-full bg-muted mb-4">
              <FileText className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No analyses yet</h3>
            <p className="text-muted-foreground mb-4 max-w-md">
              Start analyzing YouTube channels to see your history here
            </p>
            <Button>Start Analyzing</Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
