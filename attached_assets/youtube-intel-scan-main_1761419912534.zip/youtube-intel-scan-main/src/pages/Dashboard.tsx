import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Youtube, Download, Sparkles, CheckCircle2, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Video {
  id: string;
  title: string;
  publishedAt: string;
  downloaded: boolean;
}

export default function Dashboard() {
  const [channelUrl, setChannelUrl] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [videos, setVideos] = useState<Video[]>([]);
  const { toast } = useToast();

  const handleAnalyze = async () => {
    if (!channelUrl) {
      toast({
        title: "Channel URL required",
        description: "Please enter a valid YouTube channel URL",
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);
    setProgress(10);

    // Simulate fetching videos
    setTimeout(() => {
      setProgress(50);
      const mockVideos: Video[] = Array.from({ length: 12 }, (_, i) => ({
        id: `video-${i}`,
        title: `Product Management Insights #${i + 1}: Building for Scale`,
        publishedAt: new Date(Date.now() - i * 86400000).toISOString(),
        downloaded: i < 5,
      }));
      setVideos(mockVideos);
      setProgress(100);
      
      toast({
        title: "Channel analyzed",
        description: `Found ${mockVideos.length} videos, ${mockVideos.filter(v => !v.downloaded).length} new`,
      });
      
      setTimeout(() => setIsAnalyzing(false), 500);
    }, 2000);
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Hero Section */}
      <div className="text-center space-y-4 py-8">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full text-primary text-sm font-medium mb-4">
          <Sparkles className="h-4 w-4" />
          <span>AI-Powered PM Insights</span>
        </div>
        <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-foreground to-muted-foreground bg-clip-text text-transparent">
          YouTube Transcript Analyzer
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Extract actionable product management insights from YouTube channels. 
          Learn strategies, frameworks, and best practices from industry leaders.
        </p>
      </div>

      {/* Input Section */}
      <Card className="border-border/50 shadow-[var(--shadow-card)]">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Youtube className="h-5 w-5 text-primary" />
            Analyze Channel
          </CardTitle>
          <CardDescription>
            Enter a YouTube channel URL to start analyzing transcripts
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-3">
            <Input
              placeholder="https://youtube.com/@channel-name"
              value={channelUrl}
              onChange={(e) => setChannelUrl(e.target.value)}
              className="flex-1 bg-background"
              disabled={isAnalyzing}
            />
            <Button 
              onClick={handleAnalyze} 
              disabled={isAnalyzing}
              className="bg-gradient-to-r from-primary to-accent hover:opacity-90"
            >
              {isAnalyzing ? (
                <>
                  <Download className="mr-2 h-4 w-4 animate-pulse" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  Analyze
                </>
              )}
            </Button>
          </div>

          {isAnalyzing && (
            <div className="space-y-2">
              <Progress value={progress} className="h-2" />
              <p className="text-sm text-muted-foreground">
                {progress < 50 ? "Fetching channel data..." : "Loading video list..."}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Video List */}
      {videos.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">Videos Found</h2>
            <Badge variant="secondary" className="text-sm">
              {videos.filter(v => !v.downloaded).length} new videos
            </Badge>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {videos.map((video, index) => (
              <Card 
                key={video.id} 
                className={`border-border/50 hover:border-primary/50 transition-all cursor-pointer animate-fade-in hover-scale`}
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <CardHeader className="space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <CardTitle className="text-base line-clamp-2">
                      {video.title}
                    </CardTitle>
                    {video.downloaded ? (
                      <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0" />
                    ) : (
                      <Clock className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {new Date(video.publishedAt).toLocaleDateString()}
                  </p>
                  <Badge 
                    variant={video.downloaded ? "secondary" : "default"}
                    className="w-fit"
                  >
                    {video.downloaded ? "Already analyzed" : "Ready to analyze"}
                  </Badge>
                </CardHeader>
              </Card>
            ))}
          </div>

          <Button className="w-full" size="lg">
            <Download className="mr-2 h-4 w-4" />
            Download & Analyze New Videos
          </Button>
        </div>
      )}
    </div>
  );
}
