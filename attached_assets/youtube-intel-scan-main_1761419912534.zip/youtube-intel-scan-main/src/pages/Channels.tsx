import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Youtube, Video, TrendingUp, ExternalLink } from "lucide-react";

const mockChannels = [
  {
    id: "1",
    name: "Lenny's Podcast",
    url: "https://youtube.com/@LennysPodcast",
    videosAnalyzed: 47,
    lastUpdated: "2 hours ago",
    insights: 156,
  },
  {
    id: "2",
    name: "ProductSchool",
    url: "https://youtube.com/@ProductSchool",
    videosAnalyzed: 89,
    lastUpdated: "1 day ago",
    insights: 342,
  },
  {
    id: "3",
    name: "Product Hunt",
    url: "https://youtube.com/@ProductHunt",
    videosAnalyzed: 23,
    lastUpdated: "3 days ago",
    insights: 78,
  },
];

export default function Channels() {
  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Tracked Channels</h1>
          <p className="text-muted-foreground mt-2">
            Manage your YouTube channels and monitor for new content
          </p>
        </div>
        <Button className="bg-gradient-to-r from-primary to-accent">
          <Youtube className="mr-2 h-4 w-4" />
          Add Channel
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {mockChannels.map((channel, index) => (
          <Card
            key={channel.id}
            className="border-border/50 hover:border-primary/50 transition-all animate-fade-in hover-scale"
            style={{ animationDelay: `${index * 100}ms` }}
          >
            <CardHeader>
              <CardTitle className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <Youtube className="h-5 w-5 text-primary" />
                  </div>
                  <span className="text-lg">{channel.name}</span>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Video className="h-4 w-4" />
                    <span className="text-xs">Videos</span>
                  </div>
                  <p className="text-2xl font-bold">{channel.videosAnalyzed}</p>
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <TrendingUp className="h-4 w-4" />
                    <span className="text-xs">Insights</span>
                  </div>
                  <p className="text-2xl font-bold">{channel.insights}</p>
                </div>
              </div>

              <div className="pt-2 border-t border-border">
                <p className="text-xs text-muted-foreground mb-3">
                  Updated {channel.lastUpdated}
                </p>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1">
                    View Insights
                  </Button>
                  <Button variant="ghost" size="sm">
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-dashed border-2 border-border/50">
        <CardContent className="flex flex-col items-center justify-center py-12 text-center">
          <div className="p-4 rounded-full bg-primary/10 mb-4">
            <Youtube className="h-8 w-8 text-primary" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Add Your First Channel</h3>
          <p className="text-muted-foreground mb-4 max-w-md">
            Start tracking YouTube channels to automatically analyze new videos
            and extract PM insights
          </p>
          <Button className="bg-gradient-to-r from-primary to-accent">
            Get Started
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
